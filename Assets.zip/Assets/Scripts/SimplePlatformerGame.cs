using System.Collections.Generic;
using UnityEngine;

public class SimplePlatformerGame : MonoBehaviour
{
    public static SimplePlatformerGame Instance { get; private set; }

    private readonly List<GameObject> spawnedObjects = new List<GameObject>();
    private readonly List<CollectibleItem> collectibles = new List<CollectibleItem>();

    private Sprite platformSprite;
    private Sprite playerSprite;
    private Sprite coinSprite;
    private Sprite enemySprite;
    private Sprite spikeSprite;
    private Sprite flagSprite;
    private Sprite waterSprite;
    private PhysicsMaterial2D noFrictionMaterial;
    private PlayerController2D player;
    private int collectedItems;
    private bool restarting;

    public bool IsPlaying
    {
        get { return !restarting; }
    }

    public bool HasAllItems
    {
        get { return collectibles.Count > 0 && collectedItems >= collectibles.Count; }
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        Physics2D.gravity = new Vector2(0f, -9.81f);
        noFrictionMaterial = new PhysicsMaterial2D("No Friction");
        noFrictionMaterial.friction = 0f;
        noFrictionMaterial.bounciness = 0f;
        CreateSprites();
        RestartLevel();
    }

    public void CollectItem(CollectibleItem item)
    {
        if (restarting || item == null || !item.MarkCollected())
        {
            return;
        }

        collectedItems++;
    }

    public void TouchGoal()
    {
        if (HasAllItems)
        {
            RestartLevel();
        }
    }

    public void RestartLevel()
    {
        restarting = true;

        for (int i = 0; i < spawnedObjects.Count; i++)
        {
            if (spawnedObjects[i] != null)
            {
                Destroy(spawnedObjects[i]);
            }
        }

        spawnedObjects.Clear();
        collectibles.Clear();
        collectedItems = 0;
        BuildLevel();
        restarting = false;
    }

    private void BuildLevel()
    {
        CreatePlatform("Start", new Vector2(-8.5f, -4.35f), new Vector2(7.4f, 1.0f));
        CreatePlatform("Small Platform", new Vector2(-3.4f, -2.45f), new Vector2(3.4f, 0.6f));
        CreatePlatform("Middle", new Vector2(1.2f, -1.2f), new Vector2(3.7f, 0.6f));
        CreatePlatform("Enemy Platform", new Vector2(5.8f, -2.6f), new Vector2(3.8f, 0.6f));
        CreatePlatform("Step", new Vector2(9.7f, -1.35f), new Vector2(2.8f, 0.6f));
        CreatePlatform("Goal", new Vector2(13.7f, -3.55f), new Vector2(5.6f, 1.0f));
        CreateWater(new Vector2(2.5f, -6.2f), new Vector2(70f, 2.6f));

        CreateCoin(new Vector2(-10.6f, -3.25f));
        CreateCoin(new Vector2(-6.9f, -3.25f));
        CreateCoin(new Vector2(-3.4f, -1.55f));
        CreateCoin(new Vector2(1.2f, -0.3f));
        CreateCoin(new Vector2(5.8f, -1.7f));
        CreateCoin(new Vector2(9.7f, -0.45f));
        CreateCoin(new Vector2(12.4f, -2.35f));
        CreateCoin(new Vector2(14.7f, -2.35f));

        CreateSpike(new Vector2(-5.8f, -3.55f));
        CreateSpike(new Vector2(7.0f, -1.78f));
        CreateEnemy(new Vector2(12.8f, -2.72f), 11.7f, 14.4f);
        CreateGoalFlag(new Vector2(15.75f, -2.35f));

        player = CreatePlayer(new Vector2(-10.7f, -3.2f));
        CreateCamera(player.transform);
    }

    private void CreatePlatform(string objectName, Vector2 position, Vector2 size)
    {
        GameObject platform = CreateSpriteObject(objectName, platformSprite, position, size, 0);
        platform.isStatic = true;
        BoxCollider2D collider = platform.AddComponent<BoxCollider2D>();
        collider.sharedMaterial = noFrictionMaterial;
    }

    private PlayerController2D CreatePlayer(Vector2 position)
    {
        GameObject playerObject = CreateSpriteObject("Player", playerSprite, position, Vector2.one, 10);
        playerObject.tag = "Player";

        Rigidbody2D body = playerObject.AddComponent<Rigidbody2D>();
        body.gravityScale = 3.15f;
        body.freezeRotation = true;
        body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

        BoxCollider2D collider = playerObject.AddComponent<BoxCollider2D>();
        collider.size = new Vector2(0.62f, 0.9f);
        collider.sharedMaterial = noFrictionMaterial;

        GameObject groundCheck = new GameObject("Ground Check");
        Track(groundCheck);
        groundCheck.transform.SetParent(playerObject.transform);
        groundCheck.transform.localPosition = new Vector3(0f, -0.5f, 0f);

        PlayerController2D controller = playerObject.AddComponent<PlayerController2D>();
        controller.Configure(body, collider, groundCheck.transform, playerObject.GetComponent<SpriteRenderer>());
        return controller;
    }

    private void CreateWater(Vector2 position, Vector2 size)
    {
        GameObject water = CreateSpriteObject("Water", waterSprite, position, size, -1);
        BoxCollider2D collider = water.AddComponent<BoxCollider2D>();
        collider.isTrigger = true;
        water.AddComponent<RestartHazard>();
    }

    private void CreateCoin(Vector2 position)
    {
        GameObject coin = CreateSpriteObject("Coin", coinSprite, position, Vector2.one, 6);
        CircleCollider2D collider = coin.AddComponent<CircleCollider2D>();
        collider.isTrigger = true;
        collider.radius = 0.28f;

        CollectibleItem item = coin.AddComponent<CollectibleItem>();
        collectibles.Add(item);
    }

    private void CreateSpike(Vector2 position)
    {
        GameObject spike = CreateSpriteObject("Spike", spikeSprite, position, Vector2.one, 5);
        PolygonCollider2D collider = spike.AddComponent<PolygonCollider2D>();
        collider.isTrigger = true;
        collider.points = new[]
        {
            new Vector2(-0.42f, -0.42f),
            new Vector2(0f, 0.42f),
            new Vector2(0.42f, -0.42f)
        };

        spike.AddComponent<RestartHazard>();
    }

    private void CreateEnemy(Vector2 position, float leftX, float rightX)
    {
        GameObject enemy = CreateSpriteObject("Enemy", enemySprite, position, Vector2.one, 7);
        BoxCollider2D collider = enemy.AddComponent<BoxCollider2D>();
        collider.isTrigger = true;
        collider.size = new Vector2(0.75f, 0.65f);

        EnemyPatrol2D patrol = enemy.AddComponent<EnemyPatrol2D>();
        patrol.leftX = leftX;
        patrol.rightX = rightX;
        patrol.speed = 1.4f;
    }

    private void CreateGoalFlag(Vector2 position)
    {
        GameObject flag = CreateSpriteObject("Goal Flag", flagSprite, position, Vector2.one, 5);
        BoxCollider2D collider = flag.AddComponent<BoxCollider2D>();
        collider.isTrigger = true;
        collider.size = new Vector2(0.62f, 1.25f);
        collider.offset = new Vector2(0f, 0.08f);
        flag.AddComponent<GoalFlag2D>();
    }

    private void CreateCamera(Transform target)
    {
        GameObject cameraObject = new GameObject("Main Camera");
        Track(cameraObject);
        cameraObject.tag = "MainCamera";

        Camera camera = cameraObject.AddComponent<Camera>();
        camera.orthographic = true;
        camera.orthographicSize = 5.05f;
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(0.78f, 0.93f, 0.93f, 1f);
        cameraObject.AddComponent<AudioListener>();

        CameraFollow2D follow = cameraObject.AddComponent<CameraFollow2D>();
        follow.target = target;
    }

    private GameObject CreateSpriteObject(string objectName, Sprite sprite, Vector2 position, Vector2 scale, int sortingOrder)
    {
        GameObject obj = new GameObject(objectName);
        Track(obj);
        obj.transform.position = new Vector3(position.x, position.y, 0f);
        obj.transform.localScale = new Vector3(scale.x, scale.y, 1f);

        SpriteRenderer renderer = obj.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        renderer.sortingOrder = sortingOrder;
        return obj;
    }

    private void Track(GameObject obj)
    {
        spawnedObjects.Add(obj);
    }

    private void CreateSprites()
    {
        platformSprite = CreatePixelSprite("Platform", 32, 32, CreatePlatformPixel, 32f);
        playerSprite = CreatePixelSprite("Player", 24, 28, CreatePlayerPixel, 32f);
        coinSprite = CreatePixelSprite("Coin", 20, 20, CreateCoinPixel, 32f);
        enemySprite = CreatePixelSprite("Enemy", 24, 22, CreateEnemyPixel, 32f);
        spikeSprite = CreatePixelSprite("Spike", 24, 24, CreateSpikePixel, 32f);
        flagSprite = CreatePixelSprite("Flag", 24, 34, CreateFlagPixel, 32f);
        waterSprite = CreatePixelSprite("Water", 32, 16, CreateWaterPixel, 32f);
    }

    private Sprite CreatePixelSprite(string spriteName, int width, int height, System.Func<int, int, Color> pixelFactory, float pixelsPerUnit)
    {
        Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
        texture.name = spriteName + " Texture";
        texture.filterMode = FilterMode.Point;
        texture.wrapMode = TextureWrapMode.Clamp;

        Color[] pixels = new Color[width * height];
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                pixels[y * width + x] = pixelFactory(x, y);
            }
        }

        texture.SetPixels(pixels);
        texture.Apply();

        Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, width, height), new Vector2(0.5f, 0.5f), pixelsPerUnit);
        sprite.name = spriteName;
        return sprite;
    }

    private Color CreatePlatformPixel(int x, int y)
    {
        if (y > 24)
        {
            return new Color(0.08f, 0.78f, 0.35f, 1f);
        }

        if (y > 21)
        {
            return new Color(0.1f, 0.22f, 0.33f, 1f);
        }

        if (x < 1 || x > 30 || y < 1)
        {
            return new Color(0.12f, 0.17f, 0.26f, 1f);
        }

        bool dot = (x * 3 + y * 7) % 17 == 0;
        return dot ? new Color(0.85f, 0.55f, 0.3f, 1f) : new Color(0.68f, 0.38f, 0.22f, 1f);
    }

    private Color CreatePlayerPixel(int x, int y)
    {
        if (x < 3 || x > 20 || y < 1 || y > 26)
        {
            return Color.clear;
        }

        if (y > 17 && x > 5 && x < 18)
        {
            return new Color(1f, 0.82f, 0.22f, 1f);
        }

        if (y < 6 && ((x > 5 && x < 10) || (x > 13 && x < 18)))
        {
            return new Color(0.16f, 0.18f, 0.24f, 1f);
        }

        if (x == 3 || x == 20 || y == 1 || y == 26)
        {
            return new Color(0.11f, 0.16f, 0.24f, 1f);
        }

        return new Color(0.95f, 0.56f, 0.12f, 1f);
    }

    private Color CreateCoinPixel(int x, int y)
    {
        float dx = x - 9.5f;
        float dy = y - 9.5f;
        float distance = Mathf.Sqrt(dx * dx + dy * dy);

        if (distance > 8.5f)
        {
            return Color.clear;
        }

        return distance > 6.6f ? new Color(0.46f, 0.28f, 0.06f, 1f) : new Color(1f, 0.82f, 0.12f, 1f);
    }

    private Color CreateEnemyPixel(int x, int y)
    {
        if (x < 2 || x > 21 || y < 2 || y > 19)
        {
            return Color.clear;
        }

        if ((x > 5 && x < 9 && y > 12 && y < 16) || (x > 15 && x < 19 && y > 12 && y < 16))
        {
            return Color.white;
        }

        if (x == 2 || x == 21 || y == 2 || y == 19)
        {
            return new Color(0.14f, 0.17f, 0.25f, 1f);
        }

        return new Color(0.9f, 0.18f, 0.12f, 1f);
    }

    private Color CreateSpikePixel(int x, int y)
    {
        float center = 11.5f;
        float halfWidth = (1f - y / 23f) * 11f;
        if (Mathf.Abs(x - center) > halfWidth)
        {
            return Color.clear;
        }

        return new Color(0.82f, 0.82f, 0.82f, 1f);
    }

    private Color CreateFlagPixel(int x, int y)
    {
        if (x >= 16 && x <= 18 && y >= 3 && y <= 31)
        {
            return new Color(0.2f, 0.24f, 0.32f, 1f);
        }

        if (x >= 5 && x <= 16 && y >= 20 && y <= 29)
        {
            return new Color(0.9f, 0.22f, 0.12f, 1f);
        }

        return Color.clear;
    }

    private Color CreateWaterPixel(int x, int y)
    {
        if (y > 13)
        {
            return new Color(0.84f, 0.96f, 1f, 1f);
        }

        if (y > 10)
        {
            return new Color(0.16f, 0.68f, 0.94f, 1f);
        }

        return new Color(0.08f, 0.5f, 0.8f, 1f);
    }
}

public class PlayerController2D : MonoBehaviour
{
    private Rigidbody2D body;
    private BoxCollider2D bodyCollider;
    private Transform groundCheck;
    private SpriteRenderer spriteRenderer;
    private float horizontalInput;
    private int airJumpsRemaining;
    private float groundCheckDelay;

    private const int MaxAirJumps = 1;
    private const float MoveSpeed = 7.0f;
    private const float JumpForce = 10.5f;
    private const float JumpGroundDelay = 0.08f;
    private static readonly Vector2 GroundCheckSize = new Vector2(0.55f, 0.12f);

    public void Configure(Rigidbody2D assignedBody, BoxCollider2D assignedCollider, Transform assignedGroundCheck, SpriteRenderer assignedRenderer)
    {
        body = assignedBody;
        bodyCollider = assignedCollider;
        groundCheck = assignedGroundCheck;
        spriteRenderer = assignedRenderer;
        airJumpsRemaining = MaxAirJumps;
    }

    private void Update()
    {
        if (SimplePlatformerGame.Instance == null || !SimplePlatformerGame.Instance.IsPlaying)
        {
            return;
        }

        if (transform.position.y < -8.2f)
        {
            SimplePlatformerGame.Instance.RestartLevel();
            return;
        }

        if (groundCheckDelay > 0f)
        {
            groundCheckDelay -= Time.deltaTime;
        }

        bool grounded = groundCheckDelay <= 0f && IsGrounded();
        if (grounded)
        {
            airJumpsRemaining = MaxAirJumps;
        }

        horizontalInput = ReadHorizontalInput();

        if (spriteRenderer != null && Mathf.Abs(horizontalInput) > 0.01f)
        {
            spriteRenderer.flipX = horizontalInput < 0f;
        }

        if (ReadJumpPressed())
        {
            if (grounded)
            {
                Jump();
            }
            else if (airJumpsRemaining > 0)
            {
                airJumpsRemaining--;
                Jump();
            }
        }
    }

    private void FixedUpdate()
    {
        if (body == null)
        {
            return;
        }

        Vector2 velocity = body.linearVelocity;
        velocity.x = horizontalInput * MoveSpeed;
        body.linearVelocity = velocity;
    }

    private float ReadHorizontalInput()
    {
        float input = 0f;

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            input -= 1f;
        }

        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            input += 1f;
        }

        return Mathf.Clamp(input, -1f, 1f);
    }

    private bool ReadJumpPressed()
    {
        return Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow);
    }

    private void Jump()
    {
        Vector2 velocity = body.linearVelocity;
        velocity.y = 0f;
        body.linearVelocity = velocity;
        body.AddForce(Vector2.up * JumpForce, ForceMode2D.Impulse);
        groundCheckDelay = JumpGroundDelay;
    }

    private bool IsGrounded()
    {
        if (groundCheck == null || bodyCollider == null)
        {
            return false;
        }

        Collider2D[] hits = Physics2D.OverlapBoxAll(groundCheck.position, GroundCheckSize, 0f);
        for (int i = 0; i < hits.Length; i++)
        {
            Collider2D hit = hits[i];
            if (hit != null && hit != bodyCollider && !hit.isTrigger)
            {
                return true;
            }
        }

        return false;
    }
}

public class CollectibleItem : MonoBehaviour
{
    private bool collected;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController2D>() != null && SimplePlatformerGame.Instance != null)
        {
            SimplePlatformerGame.Instance.CollectItem(this);
        }
    }

    public bool MarkCollected()
    {
        if (collected)
        {
            return false;
        }

        collected = true;
        gameObject.SetActive(false);
        return true;
    }
}

public class RestartHazard : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController2D>() != null && SimplePlatformerGame.Instance != null)
        {
            SimplePlatformerGame.Instance.RestartLevel();
        }
    }
}

public class EnemyPatrol2D : MonoBehaviour
{
    public float leftX;
    public float rightX;
    public float speed = 1.4f;

    private int direction = 1;
    private SpriteRenderer spriteRenderer;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (SimplePlatformerGame.Instance == null || !SimplePlatformerGame.Instance.IsPlaying)
        {
            return;
        }

        Vector3 position = transform.position;
        position.x += direction * speed * Time.deltaTime;

        if (position.x > rightX)
        {
            position.x = rightX;
            direction = -1;
        }
        else if (position.x < leftX)
        {
            position.x = leftX;
            direction = 1;
        }

        transform.position = position;

        if (spriteRenderer != null)
        {
            spriteRenderer.flipX = direction < 0;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController2D>() != null && SimplePlatformerGame.Instance != null)
        {
            SimplePlatformerGame.Instance.RestartLevel();
        }
    }
}

public class GoalFlag2D : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController2D>() != null && SimplePlatformerGame.Instance != null)
        {
            SimplePlatformerGame.Instance.TouchGoal();
        }
    }
}

public class CameraFollow2D : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(1.4f, 1.1f, -10f);
    public float minX = -8.5f;
    public float maxX = 12.5f;
    public float minY = -1.8f;
    public float maxY = 0.2f;

    private Vector3 velocity;

    private void LateUpdate()
    {
        if (target == null)
        {
            return;
        }

        Vector3 desired = target.position + offset;
        desired.x = Mathf.Clamp(desired.x, minX, maxX);
        desired.y = Mathf.Clamp(desired.y, minY, maxY);
        desired.z = -10f;

        transform.position = Vector3.SmoothDamp(transform.position, desired, ref velocity, 0.12f);
    }
}
